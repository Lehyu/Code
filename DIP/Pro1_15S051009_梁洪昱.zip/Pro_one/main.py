from .utils.ImageUtils import *

# hist('../image/a.jpg')
gauss_highpass_filter_c('../image/e.tif', 220)
median_filter('../image/c.jpg', 3)
#　median_adaptive_filter('../image/c.jpg', 11)